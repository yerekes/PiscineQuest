package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	args := os.Args[1:]
	if len(args) < 1 {
		z01.PrintRune('\n')
		return
	}

	for i, arg := range args {
		runes := []rune(arg)
		vowelIndexes := []int{}

		for idx, r := range runes {
			if isVowel(r) {
				vowelIndexes = append(vowelIndexes, idx)
			}
		}

		n := len(vowelIndexes)
		for j := 0; j < n/2; j++ {
			a := vowelIndexes[j]
			b := vowelIndexes[n-1-j]
			runes[a], runes[b] = runes[b], runes[a]
		}

		for _, r := range runes {
			z01.PrintRune(r)
		}

		if i != len(args)-1 {
			z01.PrintRune(' ')
		}
	}
	z01.PrintRune('\n')
}

func isVowel(r rune) bool {
	switch r {
	case 'a', 'e', 'i', 'o', 'u',
		'A', 'E', 'I', 'O', 'U':
		return true
	default:
		return false
	}
}
